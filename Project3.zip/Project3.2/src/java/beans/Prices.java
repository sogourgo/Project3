/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
 
public class Prices {
        double[] pricelist = new double[3];
        
        public void prices(){
        //public static void main(String argv[]){
            try {
            File fXmlFile = new File("/home/inf2005/sogourgo/public_html/price_list.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();

            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("item");

            for (int temp = 0; temp < nList.getLength(); temp++) {

               Node nNode = nList.item(temp);
               if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                  Element eElement = (Element) nNode;

                  NodeList nlList = eElement.getElementsByTagName("price").item(0).getChildNodes();

                  Node nValue = (Node) nlList.item(0);

                  pricelist[temp] = Double.parseDouble(nValue.getNodeValue());
                  //System.out.println(temp);
                  //System.out.println(pricelist[temp]);
               }
            }
            //return pricelist[0];
        }
             catch (Exception e) {
		e.printStackTrace();
                //return -1;
	  }
    }
        
    public double getprice1(){
        return pricelist[0];
    }
    public double getprice2(){
        return pricelist[1];
    }
    public double getprice3(){
        return pricelist[2];
    }
}