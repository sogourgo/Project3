/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author sogourgo
 */
public class CheckoutBean {
        
    private String coffee, sugar, water ;
    private double total ;
    Prices sofia = new Prices();
    
    String check;
    
    double price1;
    double price2;
    double price3;
    
    double coffee1;
    double sugar1;
    double water1;
 
     public CheckoutBean() {

        coffee = "0";
        sugar = "0";
        water = "0";
        coffee1 = 0;
        sugar1 = 0;
        water1 = 0;
        check = "false";
        
        //Quantity = "0";
        total = 0;
        sofia.prices();
        price1 = sofia.getprice1();
        price2 = sofia.getprice2();
        price3 = sofia.getprice3();
        
    }
 
  
    public String getCoffee() {
        return this.coffee;
    }
 
    public void setCoffee(final String coffee) {
        this.coffee = "0";
    }
 
    
    public String getSugar() {
        return this.sugar;
    }
 
    public void setSugar(final String sugar) {
        this.sugar = "0";
    }
    
    public String getWater() {
        return this.water;
    }
 

    public void setWater(final String water) {
        this.water = "0";
    }
    
    public double getCoffee1(){
    
       return 0.0;
    
    } 
    
    public double getSugar1(){
    
       return 0.0;
    
    } 
        
    public double getWater1(){
    
       return 0.0;
    
    }  
    
    public double getTotal(){
       
        return 0.0;
    }

    
    public double getPrice1() {
        return this.price1;
    }
    
    public double getPrice2() {
        return this.price2;
    }
    
    public double getPrice3() {
        return this.price3;
    }
    
    
    public void setCheck(final String check){
    
        this.check = check;
    
    }
    
    public String getCheck(){
    
        return this.check;
    }
}
